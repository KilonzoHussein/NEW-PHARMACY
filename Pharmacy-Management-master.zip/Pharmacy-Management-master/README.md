# pharmacy-management-api

Swagger api [location](./config/swagger.yaml)
