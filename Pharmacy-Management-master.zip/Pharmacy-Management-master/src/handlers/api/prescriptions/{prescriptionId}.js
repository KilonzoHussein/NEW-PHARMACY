'use strict';
// var dataProvider = require('../../../data/api/prescriptions/{prescriptionId}.js');
/**
 * Operations on /api/prescriptions/{prescriptionId}
 */
module.exports = {
    /**
     * summary: Get prescription details
     * description: Retrieve details of a specific prescription by ID.
     * parameters: prescriptionId
     * produces: 
     * responses: 200, 404
     */
    get: function (req, res, next) {
        /**
         * Get the data for response 200
         * For response `default` status 200 is used.
         */
        var status = 200;
        var provider = dataProvider['get']['200'];
        provider(req, res, function (err, data) {
            if (err) {
                next(err);
                return;
            }
            res.status(status).send(data && data.responses);
        });
    },
    /**
     * summary: Update prescription details
     * description: Update the details of a specific prescription by ID.
     * parameters: prescriptionId, body
     * produces: 
     * responses: 200, 404
     */
    put: function (req, res, next) {
        /**
         * Get the data for response 200
         * For response `default` status 200 is used.
         */
        var status = 200;
        var provider = dataProvider['put']['200'];
        provider(req, res, function (err, data) {
            if (err) {
                next(err);
                return;
            }
            res.status(status).send(data && data.responses);
        });
    },
    /**
     * summary: Delete prescription
     * description: Delete a specific prescription by ID.
     * parameters: prescriptionId
     * produces: 
     * responses: 204, 404
     */
    delete: function (req, res, next) {
        /**
         * Get the data for response 204
         * For response `default` status 200 is used.
         */
        var status = 204;
        var provider = dataProvider['delete']['204'];
        provider(req, res, function (err, data) {
            if (err) {
                next(err);
                return;
            }
            res.status(status).send(data && data.responses);
        });
    }
};
